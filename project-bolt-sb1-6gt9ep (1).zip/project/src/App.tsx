import React, { useCallback } from 'react';
import { Header } from './components/Header';
import { TranscriptionBox } from './components/TranscriptionBox';
import { Controls } from './components/Controls';
import { useSpeechRecognition } from './hooks/useSpeechRecognition';

function App() {
  const {
    text,
    isListening,
    startListening,
    stopListening,
    hasRecognitionSupport,
    error
  } = useSpeechRecognition();

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(text);
  }, [text]);

  if (!hasRecognitionSupport) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="max-w-4xl mx-auto p-6">
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
            Sorry, your browser doesn't support speech recognition.
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto p-6 space-y-6">
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
            {error}
          </div>
        )}

        <TranscriptionBox text={text} />
        
        <Controls
          isListening={isListening}
          onStartListening={startListening}
          onStopListening={stopListening}
          onCopy={handleCopy}
          hasText={text.length > 0}
        />
      </main>
    </div>
  );
}

export default App;