import React from 'react';
import { Mic, MicOff, Copy } from 'lucide-react';

interface ControlsProps {
  isListening: boolean;
  onStartListening: () => void;
  onStopListening: () => void;
  onCopy: () => void;
  hasText: boolean;
}

export function Controls({
  isListening,
  onStartListening,
  onStopListening,
  onCopy,
  hasText
}: ControlsProps) {
  return (
    <div className="flex justify-center space-x-4">
      <button
        onClick={isListening ? onStopListening : onStartListening}
        className={`flex items-center space-x-2 px-6 py-3 rounded-full font-medium transition-all ${
          isListening
            ? 'bg-red-500 hover:bg-red-600 text-white'
            : 'bg-purple-600 hover:bg-purple-700 text-white'
        }`}
      >
        {isListening ? (
          <>
            <MicOff className="w-5 h-5" />
            <span>Stop Recording</span>
          </>
        ) : (
          <>
            <Mic className="w-5 h-5" />
            <span>Start Recording</span>
          </>
        )}
      </button>
      
      {hasText && (
        <button
          onClick={onCopy}
          className="flex items-center space-x-2 px-6 py-3 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium transition-all"
        >
          <Copy className="w-5 h-5" />
          <span>Copy Text</span>
        </button>
      )}
    </div>
  );
}