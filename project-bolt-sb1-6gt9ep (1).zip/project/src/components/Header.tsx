import React from 'react';
import { Mic } from 'lucide-react';

export function Header() {
  return (
    <header className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 p-6">
      <div className="max-w-4xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Mic className="w-8 h-8 text-white" />
          <h1 className="text-2xl font-bold text-white">VoiceScribe</h1>
        </div>
      </div>
    </header>
  );
}