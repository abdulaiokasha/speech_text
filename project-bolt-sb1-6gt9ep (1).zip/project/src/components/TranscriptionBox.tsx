import React from 'react';

interface TranscriptionBoxProps {
  text: string;
}

export function TranscriptionBox({ text }: TranscriptionBoxProps) {
  return (
    <div className="w-full bg-white rounded-lg shadow-lg p-6 min-h-[200px] relative">
      {text ? (
        <p className="text-gray-700 whitespace-pre-wrap">{text}</p>
      ) : (
        <p className="text-gray-400 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
          Your transcription will appear here...
        </p>
      )}
    </div>
  );
}